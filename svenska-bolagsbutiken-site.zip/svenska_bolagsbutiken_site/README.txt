Svenska Bolagsbutiken – Mini-site (statisk)
==========================================

Filer:
- index.html (Start)
- kop-aktiebolag.html (Köp + formulär-demo)
- faq.html (FAQ)
- assets/style.css
- assets/illustration.svg (plats­hållare)
- assets/buy.js (enkelt stegformulär + röd/grön-demo)

Hur du använder detta:
1) För en snabb test: öppna index.html i webbläsaren.
2) För webben: ladda upp filerna till valfri webbserver.

WordPress (enkelt sätt):
- Skapa sidorna "Start", "Köp aktiebolag", "FAQ".
- Klistra in motsvarande HTML i ett HTML-block (t.ex. via Gutenberg "Anpassad HTML").
- Alternativt: använd detta som mall för din sidbyggare.
- Byt kontaktmail i footern (sök efter kontakt@exempel.se).
- Byt Swish-instruktionerna/fakturaflödet i kop-aktiebolag.html (just nu demo-popups).

Notera:
Formuläret är en demo i statisk HTML/JS. I WordPress rekommenderas Gravity Forms / Fluent Forms / WPForms
för att faktiskt spara data och maila er automatiskt.
