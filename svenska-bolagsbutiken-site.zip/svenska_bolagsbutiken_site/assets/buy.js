(function(){
  const steps = Array.from(document.querySelectorAll('.form-step'));
  const pills = Array.from(document.querySelectorAll('.step'));
  let i = 0;

  function show(idx){
    steps.forEach((s, si)=>s.classList.toggle('active', si===idx));
    pills.forEach((p, pi)=>p.classList.toggle('active', pi===idx));
    i = idx;
    window.scrollTo({top:0, behavior:'smooth'});
  }

  function val(id){ return (document.getElementById(id)?.value || '').trim(); }
  function checked(id){ return !!document.getElementById(id)?.checked; }

  function buildSummary(){
    const map = [
      ['Köper som', val('buyer_type')],
      ['Namn', val('full_name')],
      ['Personnummer', val('pnr')],
      ['E‑post', val('email')],
      ['Telefon', val('phone')],
      ['Önskat bolagsnamn', val('company_name') || '—'],
      ['Verksamhet', val('business_desc') || '—'],
      ['Kommun', val('kommun') || '—'],
      ['Adress', val('address') || '—'],
      ['VD', `${val('ceo_name')} (${val('ceo_pnr')})`],
      ['Styrelseledamot', `${val('board_name')} (${val('board_pnr')})`],
    ];
    const tbody = document.getElementById('summary_tbody');
    tbody.innerHTML = '';
    map.forEach(([k,v])=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${k}</td><td>${v}</td>`;
      tbody.appendChild(tr);
    });
  }

  function isRed(){
    // Red if any disallowed conditions are selected/checked
    const highrisk = checked('risk_crypto') || checked('risk_gambling') || checked('risk_payments') || checked('risk_permit');
    const pep = document.querySelector('input[name="pep"]:checked')?.value === 'yes';
    const must = checked('confirm_sweden') && checked('confirm_pnr') && checked('confirm_bank') && checked('confirm_correct') && checked('confirm_terms');
    return highrisk || pep || !must;
  }

  document.querySelectorAll('[data-next]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      // simple required checks per step
      if(i===0){
        const req = ['buyer_type','full_name','pnr','email','phone'];
        const missing = req.filter(r=>!val(r));
        if(missing.length){ alert('Fyll i alla obligatoriska fält.'); return; }
      }
      if(i===1){
        const req = ['business_desc','kommun','address'];
        const missing = req.filter(r=>!val(r));
        if(missing.length){ alert('Fyll i verksamhet, kommun och adress.'); return; }
      }
      if(i===2){
        const req = ['ceo_name','ceo_pnr','board_name','board_pnr'];
        const missing = req.filter(r=>!val(r));
        if(missing.length){ alert('Fyll i rollerna (VD och styrelseledamot).'); return; }
      }
      if(i===3){
        if(isRed()){
          document.getElementById('red_block').style.display = 'block';
          document.getElementById('go_pay').style.display = 'none';
          show(4);
          return;
        }
        buildSummary();
      }
      show(Math.min(i+1, steps.length-1));
    });
  });

  document.querySelectorAll('[data-prev]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      show(Math.max(i-1, 0));
    });
  });

  // Payment buttons (placeholders)
  document.getElementById('pay_swish').addEventListener('click', (e)=>{
    e.preventDefault();
    alert('Demo: här visar du Swish-instruktion (nummer + belopp + meddelande).');
  });
  document.getElementById('pay_invoice').addEventListener('click', (e)=>{
    e.preventDefault();
    alert('Demo: här skickar ni faktura via ert faktureringsprogram. Visa en bekräftelsesida.');
  });

  show(0);
})();
